package net.codejava;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@ContextConfiguration
class SpringBootEmailExamplesApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}

}
